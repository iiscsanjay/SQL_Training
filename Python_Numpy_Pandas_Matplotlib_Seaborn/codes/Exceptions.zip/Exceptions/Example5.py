#!/usr/bin/python3
"""
Exception
try
except ....
"""
import sys


def main():

    try:
        number = int(input('Enter a Positive Number: '))
        if number < 0 :
            raise ValueError
    except ValueError:
        print(f'Number should be positive!')
        sys.exit(-1)
    except:
        print(f'General Exception Occured!')

# boiler syntax
if __name__ == "__main__":
    main()
